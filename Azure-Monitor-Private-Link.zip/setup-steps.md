# Setup Steps

## Step 1: Resource Group
Create `AzureMonitor-Private-RG`.

## Step 2: Log Analytics Workspace
Create `azuremonitor-private-rg`.

## Step 3: Azure Monitor Private Link Scope
Create `Monitor-AMPLS`.

## Step 4: Add Log Analytics Workspace
Add `azuremonitor-private-rg` under AMPLS → Azure Monitor Resources.

## Step 5: Data Collection Endpoint
Create `Monitor-DCE` in East Asia.

## Step 6: Add DCE to AMPLS
Add `Monitor-DCE` to AMPLS → Azure Monitor Resources.

## Step 7: Data Collection Rule
Create `Monitor-DCR` in East Asia.
Configure:
- Linux Syslog
- Performance Counters
- Destination: Log Analytics Workspace
- DCE: Monitor-DCE

## Step 8: VNet and Subnet
VNet: `vnet-eastasia-1`
Address space: `172.16.0.0/16`
Subnet: `snet-eastasia-1`
Subnet range: `172.16.0.0/24`

## Step 9: Linux VM
VM: `Monitor-VM-EA`
Region: East Asia
OS: Ubuntu 24.04 LTS
VNet: `vnet-eastasia-1`
Subnet: `snet-eastasia-1`
Public IP: None

## Step 10: Install Azure Monitor Agent
Install `AzureMonitorLinuxAgent` on the VM.

## Step 11: Associate DCR
Associate `Monitor-DCR` with `Monitor-VM-EA`.

## Step 12: Associate DCE
Associate `Monitor-DCE` with `Monitor-VM-EA`.

## Step 13: Private Endpoint
Private Endpoint: `Monitor-PrivateEndpoint-EA`
Target: `Monitor-AMPLS`
Sub-resource: `azuremonitor`
VNet: `vnet-eastasia-1`
Subnet: `snet-eastasia-1`

## Step 14: Private DNS
Configure the required Azure Monitor Private DNS zones and link them to `vnet-eastasia-1`.

## Step 15: AMPLS Access Modes
Set:
- Ingestion: Private Only
- Query: Private Only

## Step 16: Generate Test Telemetry
Run the logger command from the Linux VM.

## Step 17: Verify Syslog
Run the Syslog KQL query in Log Analytics.

## Step 18: Verify Heartbeat
Run the Heartbeat KQL query in Log Analytics.
